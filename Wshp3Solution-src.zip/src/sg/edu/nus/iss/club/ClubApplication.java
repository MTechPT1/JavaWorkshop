package sg.edu.nus.iss.club;
public class ClubApplication {

    public static void main (String args[]) {

        Club club = new Club ();

        Member removableMember;

        club.addMember ("Einstein", "Albert", null);
        club.addMember ("Picasso", "Pablo", "Ruiz");
        removableMember = club.addMember ("Webber","Andrew","Lloyd");
        club.addMember ("Baggio", "Roberto", null);
        club.addMember ("Raffles", "Stamford", null);

        System.out.println ("Current Members:");
        club.showMembers ();

        System.out.println ("Deleting " + removableMember);
        int id = removableMember.getMemberNumber ();
        club.removeMember (id);

        System.out.println ("Current members:");
        club.showMembers ();
    }

}
